----------------------------------------------------------
|INFORMATION & WARNING of PickPic                        |
|  Welcome to use my first application named pickpic!    |
|  This application is based on java language relized    |
|  find pictures at Bing Image by key words inputed in   |
|  command line.                                         |
|  How to use it?                                        |
|    you just need to input three parameters such as:    |
|    F:\image\ cartoon+niko 1000                         |
|    *[F:\image\] is the local path where you want images|
|      to store.                                         |
|    *[cartoon+niko] is the search key words.            |
|    *[1000] is the approximate count of images          | 
|     dowloaded.                                         |
|  The application only has the simple function. I will  |       
|  update it in free time.                               |
|  If you are interested in the application, you can     |
|    obtain the source code at GitHub. The link is       |
|    https://github.com/NikolaZhang/PickPic              |
|                            author: NikolaZhang         |
|                            mail  : NikolaZhang@163.com |
----------------------------------------------------------